# This package contains DJANGO tags in the normal Django style
# Don't put regular DMP or Mako things in it.
