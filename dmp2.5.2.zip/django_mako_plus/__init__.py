#
#   Author:  Conan Albrecht <ca&byu,edu>
#   License: Apache Open Source License
#


# The version of DMP - used by sdist to publish to PyPI
__version__ = '2.5.2'

